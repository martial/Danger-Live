/*
 *  componentData.cpp
 *  danger_live
 *
 *  Created by Martial Geoffre on 07/02/2011.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "componentData.h"

componentData::componentData() {

}

componentData::~componentData() {

}