/*
 *  bloomEffect.cpp
 *  danger_live
 *
 *  Created by Martial Geoffre on 24/02/2011.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "bloomEffect.h"

